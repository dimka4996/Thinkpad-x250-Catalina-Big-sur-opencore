# cd To the current directory
# perform ./install.sh
